<?php
        function parallaxsome_dynamic_styles() {
        	/*wp_enqueue_style(
        		'custom-style',
        		get_template_directory_uri() . '/css/custom_script.css'
        	);*/
                $tpl_color = sanitize_hex_color(get_theme_mod( 'parallaxsome_tpl_color', '#e23815' ));
                $custom_css = "
                        .main-navigation ul.menu > li > a:after,
                        .single-slide-wrap .slider-title:before,
                        .single-slide-wrap .slider-title:after,
                        .ps-front-slider-wrapper .bx-wrapper .bx-pager.bx-default-pager a:hover,
                        .ps-front-slider-wrapper .bx-wrapper .bx-pager.bx-default-pager a.active,
                        .service-tab-content .content-right .ps-btn,
                        .service-tab-content .tab-pane .ps-btn,
                        .ps-home-section#section-fact .ps-fact-icon,
                        #section-portfolio .project-icons a,
                        .ps-protfolio-wrapper ul#psProjects li:hover .project-info-wrap,
                        #section-blog .ps-section-viewall a:hover,
                        #section-contact input[type=submit],
                        .footer-social-wrap .ps-social-icons-wrapper a:hover,
                        #scroll-up,
                        .ps-section-viewall a:hover,
                        #section-blog .ps-section-viewall a,
                        .widget_search input[type=submit], .archive #primary .search-submit,
                        .comments-area .form-submit input[type=submit],
                        .nav-links .page-numbers.current,
                        .nav-links a.page-numbers:hover,
                        .nav-links .page-numbers.current,
                        .nav-links a.page-numbers:hover,
                        .comments-area .reply .comment-reply-link:hover{
                                background-color: {$tpl_color};
                        }";

                $custom_css .= "
                        .ps-head-search .ps-search-icon:before,
                        .ps-section-viewall a,
                        .service-nav-tab li a:hover,
                        .service-nav-tab li.active a,
                        .service-tab-content .content-right .ps-btn:hover,
                        .service-tab-content .tab-pane .ps-btn:hover,
                        a:hover, a:focus, a:active,
                        .ps-blog-poston a:hover,
                        #primary .blog-content-wrap a:hover,
                        a.ps-more-button:hover,
                        #section-contact .ps-num-label:before,
                        #section-contact .ps-mag-caption:hover,
                        #section-portfolio .project-icons a:hover,
                        #section-contact input[type=submit]:hover,
                        #section-contact .ps-add-label:before,
                        .ps-innerpages-header-wrapper #crumbs a,
                        .widget-title,
                        .widget-area .widget a:hover,
                        #primary .blog-content-wrap .cat-links a,
                        #primary article.post .entry-meta a:hover,
                        .comment-navigation a:hover:before,
                        .posts-navigation a:hover:before,
                        .post-navigation a:hover:before,
                        .comments-area .comments-title,
                        .comments-area .comment-reply-title,
                        .arcitle-more-btn a:hover,
                        .arcitle-more-btn a:hover:after,
                        .comments-area a:hover,
                        .comments-area .comment-author .fn a:hover,
                        .comments-area .reply .comment-reply-link,
                        .edit-link a:hover:before{
                                color: {$tpl_color};
                        }";

                $custom_css .= "
                        .ps-section-viewall a,
                        #section-portfolio .project-icons a,
                        a.ps-more-button:before,
                        a.ps-more-button:after,
                        #section-contact input[type=submit],
                        .footer-social-wrap .ps-social-icons-wrapper a:hover,
                        #section-blog .ps-section-viewall a,
                        .widget_search input[type=submit], .archive #primary .search-submit,
                        .comments-area .form-submit input[type=submit],
                        .nav-links .page-numbers.current,
                        nav-links a.page-numbers:hover,
                        .nav-links .page-numbers.current,
                        .nav-links a.page-numbers:hover,
                        .comments-area .reply .comment-reply-link:hover{
                                border-color: {$tpl_color};
                        }";

                $custom_css .= "
                        .ps-home-section#section-fact .ps-fact-icon:after{
                                border-color: transparent transparent transparent {$tpl_color};
                        }";
                wp_add_inline_style( 'parallaxsome-style', $custom_css );
        }

        add_action( 'wp_enqueue_scripts', 'parallaxsome_dynamic_styles' );