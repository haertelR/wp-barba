=== AcmePhoto ===

AcmePhoto is one of the best WordPress photography Theme based on masonry layout. Carefully Crafted theme with Creativity for photography, art portfolio, freelancer and other creative photography centric websites. A very flexible theme with dozens of premium features including multiple menu position, control the height of slider/featured section, advanced pagination options and many more. An elegant theme with quality code and based on customizer. A translation ready theme with major browser compatibility. AcmePhoto comes with lots of features including logo options, site layout options, header options, footer options, sidebar options as well as color options too. Related posts, breadcrumb, search options, social icons, custom widgets are also the added features on this theme. This theme packs a lot of premium features which helps you to make your site awesome and well organized. Try yourself today and check it out. Demo-1: http://demo.acmethemes.com/acmephoto, Demo-2: http://www.demo.acmethemes.com/acmephoto/home-1/, Supports: https://www.acmethemes.com/supports/

Contributors: acmethemes

Tags: one-column, two-columns, three-columns, left-sidebar, right-sidebar, grid-layout, custom-background, custom-colors, custom-menu, custom-logo, featured-images, footer-widgets, full-width-template, sticky-post, theme-options, threaded-comments, translation-ready, blog, photography, portfolio

Requires at least: 4.4
Tested up to: 4.6.1
Stable tag: 1.0.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

AcmePhoto is one of the best WordPress photography Theme based on masonry layout. Carefully Crafted theme with Creativity for photography, art portfolio, freelancer and other creative photography centric websites. A very flexible theme with dozens of premium features including multiple menu position, control the height of slider/featured section, advanced pagination options and many more. An elegant theme with quality code and based on customizer. A translation ready theme with major browser compatibility. AcmePhoto comes with lots of features including logo options, site layout options, header options, footer options, sidebar options as well as color options too. Related posts, breadcrumb, search options, social icons, custom widgets are also the added features on this theme. This theme packs a lot of premium features which helps you to make your site awesome and well organized. Try yourself today and check it out. Demo-1: http://demo.acmethemes.com/acmephoto, Demo-2: http://www.demo.acmethemes.com/acmephoto/home-1/, Supports: https://www.acmethemes.com/supports/

== Translation ==

AcmePhoto theme is translation ready.

== License ==
AcmePhoto is based on Underscores http://underscores.me/, (C) 2012-2014 Automattic, Inc.
Unless otherwise specified, all the theme files, scripts and images are licensed under GNU General Public License Version 2 or later.
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
AcmePhoto WordPress Theme, Copyright 2016 AcmeThemes
AcmePhoto is distributed under the terms of the GNU General Public License v2 or later
The exceptions to license are as follows:

* Based on Underscores http://underscores.me/, (C) 2012-2015 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* Google Fonts - Apache License, version 2.0
* normalize.css http://necolas.github.io/normalize.css/, (C) 2012-2015 Nicolas Gallagher and Jonathan Neal, [MIT](http://opensource.org/licenses/MIT)
* Font-Awesome https://github.com/FortAwesome/Font-Awesome [MIT](http://opensource.org/licenses/MIT)- by @davegandy
* html5shiv https://github.com/afarkas/html5shiv [MIT](http://opensource.org/licenses/MIT) by @afarkas @jdalton @jon_neal @rem
* Cycle2 http://jquery.malsup.com/cycle2/ [MIT](http://opensource.org/licenses/MIT) - Copyright (c) 2014 M. Alsup; Dual licensed: MIT/GPL
* respond.min https://github.com/scottjehl/Respond [MIT](http://opensource.org/licenses/MIT) Copyright 2011 Scott Jehl, scottjehl.com

Image used in screenshot
https://pixabay.com/en/travel-travel-adventure-adventure-1233762/- License CC0 Public Domain
https://pixabay.com/en/girl-beautiful-young-happy-person-422334/- License CC0 Public Domain
https://pixabay.com/en/girl-blonde-dress-blue-lake-1526883/ - License CC0 Public Domain
https://pixabay.com/en/girl-hyacinth-flowers-nature-1532733/- License CC0 Public Domain

Other Images:
no-image-avalable.png self created GPLv2

== Installation ==
	
1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Usage ==

=== Customization site ===
1. In the admin area, go to Appearance > Customize
2. You wll find different options in customizer